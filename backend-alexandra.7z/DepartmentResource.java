package com.mycompany.myapp.web.rest;

import com.mycompany.myapp.domain.Department;
import com.mycompany.myapp.service.DepartmentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/department")
public class DepartmentResource {

    private final Logger log = LoggerFactory.getLogger(DepartmentResource.class);

    @Autowired
    private DepartmentService departmentService;

    @PostMapping("/add")
    @ResponseStatus(HttpStatus.CREATED)
    public Department createEmployee(@RequestBody @Valid Department department){
        Department employee1 = departmentService.save(department);
        return  department;
    }

    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable("id") Long id) {
        departmentService.delete(id);
    }

    @GetMapping("/get/{id}")
    public Department findOne(@PathVariable("id") Long id){
        return departmentService.findOne(id);
    }

    @PutMapping("/update")
    public void update(@RequestBody @Valid Department department){
        departmentService.update(department);
    }

    @GetMapping("/findAll")
    public List<Department> findAll(){
        return departmentService.findAll();
    }

}

