package com.mycompany.myapp.service;

import com.mycompany.myapp.domain.Job;
import com.mycompany.myapp.repository.JobRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class JobService {

    @Autowired
    JobRepository jobRepository;

    public List<Job> findAll(){
        return (List<Job>) jobRepository.findAll();
    }


}
