package com.mycompany.myapp.service;

import com.mycompany.myapp.domain.Employee;
import com.mycompany.myapp.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class EmployeeService {

    @Autowired
    EmployeeRepository employeeRepository;

    public List<Employee> findAll(){
        return (List<Employee>) employeeRepository.findAll();
    }

    public Employee save(Employee employee){
        System.out.println(employee);
        return employeeRepository.save(employee);
    }

    public void delete(Long id){
        employeeRepository.delete(id);
    }

    public Employee findOne(Long id){
        return employeeRepository.findOne(id);
    }

    public void update(Employee employee){
        employeeRepository.delete(employee);
        employeeRepository.save(employee);
    }


}
