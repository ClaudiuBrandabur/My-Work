package com.mycompany.myapp.domain;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "locations")
public class Location implements Serializable {

    @Id
    @Column(name = "location_id")
    private Long locationId;

    @Column(name = "street_address")
    private String streetAddress;

    @Column(name = "postal_code")
    private String postalCode;

    @Column(name = "city")
    private String city;

    @Column(name = "state_province")
    private String stateProvince;


    public Long getId() {
        return locationId;
    }

    public void setId(Long locationId) {
        this.locationId = locationId;
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStateProvince() {
        return stateProvince;
    }

    public void setStateProvince(String stateProvince) {
        this.stateProvince = stateProvince;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;

        if (obj == null || getClass() != obj.getClass()) return false;

        Location location = (Location) obj;
        if (!locationId.equals(location.locationId)) return false;
        if (!city.equals(location.city)) return false;
        if (!streetAddress.equals(location.streetAddress)) return false;
        if (!postalCode.equals(location.postalCode)) return false;
        if (!stateProvince.equals(location.stateProvince)) return false;

        return true;
    }

    @Override
    public String toString() {
        return "Location{" +
            "id=" + locationId +
            ", streetAddress='" + streetAddress + '\'' +
            ", postalCode='" + postalCode + '\'' +
            ", city='" + city + '\'' +
            ", stateProvince='" + stateProvince + '\'' +
            '}';
    }
}
