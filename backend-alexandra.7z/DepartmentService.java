package com.mycompany.myapp.service;

import com.mycompany.myapp.domain.Department;
import com.mycompany.myapp.repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class DepartmentService {

    @Autowired
    DepartmentRepository employeeRepository;

    public List<Department> findAll(){
        return (List<Department>) employeeRepository.findAll();
    }

    public Department save(Department department){
        return employeeRepository.save(department);
    }

    public void delete(Long id){
        employeeRepository.delete(id);
    }

    public Department findOne(Long id){
        return employeeRepository.findOne(id);
    }

    public void update(Department department){
        employeeRepository.delete(department);
        employeeRepository.save(department);
    }
}
