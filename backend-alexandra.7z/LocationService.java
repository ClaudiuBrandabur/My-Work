package com.mycompany.myapp.service;

import com.mycompany.myapp.domain.Location;
import com.mycompany.myapp.repository.LocationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class LocationService {

    @Autowired
    LocationRepository locationRepository;

    public List<Location> findAll(){
        return (List<Location>) locationRepository.findAll();
    }

}
