package com.mycompany.myapp.web.rest;


import com.codahale.metrics.annotation.Timed;
import com.mycompany.myapp.domain.Employee;
import com.mycompany.myapp.service.EmployeeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("employee")
public class EmployeeResource {

    private final Logger log = LoggerFactory.getLogger(EmployeeResource.class);

    @Autowired
    private EmployeeService employeeService;

    @RequestMapping(path = "/add",
                    method = RequestMethod.POST,
                    consumes= MediaType.APPLICATION_JSON_VALUE)
    public Employee createEmployee(@Valid @RequestBody Employee employee){
        System.out.println("create");
        Employee employee1 = employeeService.save(employee);
        return  employee;
    }

    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable("id") Long id) {
        employeeService.delete(id);
    }

    @GetMapping("/get/{id}")
    public Employee findOne(@PathVariable("id") Long id){
        return employeeService.findOne(id);
    }

    @PutMapping("/update")
    @Timed
    public void update(@Valid @RequestBody Employee employee){
        employeeService.update(employee);
    }

    @GetMapping("/findAll")
    public List<Employee> findAll(){
        return employeeService.findAll();
    }

}
